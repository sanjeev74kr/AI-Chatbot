import React from "react";
import { useState, useEffect } from "react";
import '../styles/chat.css'
import industryData from '../data/industryData';
import { defaultMessages, defaultReply } from "../data/defaultMessages.js";
import chatHistory from "../data/chatHistory";
import { useDispatch } from "react-redux";
import queryAction from "../redux/queryAction";
import { useSelector } from 'react-redux'
import { handleAns, handleQandA } from "../redux/CounterSlice";


function Chat() {
    //variables
    const [isExpanded, setIsExpanded] = useState({}); // Plus button of left side
    const [inputValue, setInputValue] = useState('');
    const [isDefaultMessages, setIsDefaultMessages] = useState(defaultMessages);
    const [userQuery, setUserQuery] = useState([]);
    const [isChatHistoryToggle, setIsChatHistoryToggle] = useState(false);
    const [updatedChatHistory, setUpdatedChatHistory] = useState(chatHistory);
    const [isLeftSectionToggle, setIsLeftSectionToggle] = useState(true);
    const [editingIndices, setEditingIndices] = useState({});
    const [query, setQuery] = useState('');
    const [answer, setAnswer] = useState("");

    const dispatch = useDispatch();

const queandans = useSelector((state)=> state.counter.query)


    //1. Handle industry-data if it has nested items
    const handleExpandButton = (index) => {
        if (industryData[index])
            setIsExpanded((prevState) => ({
                ...prevState,
                [index]: !prevState[index]
            }));
    };


    //2. Handle Search input box
    const handleInputChange = (e) => {
        setInputValue(e.target.value);
        setQuery(e.target.value);
    }


    //3. Handle user userQuery of chat conversation
    const handleSendQueryButton = async () => {
        if (inputValue.trim() === '') return;

        const newQuery = {
            que: inputValue,
            isUser: true,
        };

        try {

            const response = await fetch(`http://127.0.0.1:8000/Ron/`, {

                method: 'POST',
                headers: {
                    // 'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 'query': query }),

                // mode: 'cors'
                 // Use 'cors' mode instead of 'no-cors'

            }).then(async (result)=>{
                if(result.status===200){
                    const answer = await result.json();
                    console.log("answer",answer);
                    dispatch(handleQandA({ que: inputValue, ans: answer }))
                }

            }).catch(e=>{
                console.log("Error:",e);

            })



            // const answer = await response.json();
            // dispatch(handleQandA({ que: inputValue, ans: answer }))

            // console.log("Answer from backend is: ", answer);


        } catch (error) {

            console.error("Error fetching answer:", error);



        }
        setIsDefaultMessages([]);

        setQuery(newQuery.text);

        dispatch(queryAction(newQuery.text));


        setUserQuery([...userQuery, newQuery]);

        setInputValue('');

        setTimeout(() => {
            const conversationContainer = document.querySelector(".chats-conversation-container");
            conversationContainer.scrollTop = conversationContainer.scrollHeight;
        }, 10);
    }


    //4. Handle when user press enter button while writing in  input box 
    const handleEnterPressed = (e) => {
        if (e.key === 'Enter')
            handleSendQueryButton();

    }


    //5.  open-close chatHistory section of right side
    const handleToggleChatHistoryButton = () => {
        setIsChatHistoryToggle(!isChatHistoryToggle);
    }


    //6. for new conversation on cllick of new chat button 
    const handleNewChatButton = () => {
        setUserQuery([]);
        setIsDefaultMessages([]);
        dispatch(handleAns())
    }


    //7.Handle copy button
    const handleCopy = (text) => {
        navigator.clipboard.writeText(text);
    }

    //8.Handle download button
    const handleDownload = (ques, ans) => {
        const content = `Query: ${ques}\nAnswer: ${ans}`;
        const blob = new Blob([content], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = 'RON-Reply.txt';
        document.body.appendChild(a);

        a.click();

        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    };



    //10. Handle File Upload
    const handleFileUpload = (e) => {
        const selectedFile = e.target.files[0];

        if (selectedFile) {
            const reader = new FileReader();

            reader.onload = (event) => {
                const fileContent = event.target.result;
                setInputValue(fileContent);
            };

            reader.readAsText(selectedFile, 'UTF-8');
        }

    }


    //11. handle-left-section-toggle-button
    const handleLeftSectionToggleButton = () => {
        if (window.innerWidth <= 768)
            setIsLeftSectionToggle(true);
        else
            setIsLeftSectionToggle(!isLeftSectionToggle);
    }
    useEffect(() => {
        const mediaQuery = window.matchMedia("(max-width: 768px)");

        // Initial call to handle left section toggle based on screen width
        handleLeftSectionToggleButton(mediaQuery.matches);

        // Add listener for screen width changes
        const handleMediaQueryChange = (e) => {
            handleLeftSectionToggleButton(e.matches);
        };

        mediaQuery.addListener(handleMediaQueryChange);

        // Clean up the listener when component unmounts
        return () => {
            mediaQuery.removeListener(handleMediaQueryChange);
        };
    }, []); // Empty dependency array to run this effect only once


    //12. handle delete button
    const handleDelete = (date, index) => {
        const updatedChatHistory = { ...chatHistory };
        updatedChatHistory[date].splice(index, 1);
        setUpdatedChatHistory(updatedChatHistory);
    }

    //13.  Update the editing index for a specific date
    const handleEdit = (date, index) => {
        setEditingIndices((prevEditingIndices) => ({
            ...prevEditingIndices,
            [date]: index,
        }));
    };


    // const result = useSelector((state) => state.botReply.response?.output_text);

    useEffect(() => {
        // setAnswer(result || "");
        // const temp = async () => {
        //     try {
    
        //         const response = await fetch(`http://127.0.0.1:8000/Ron/`, {
    
        //             method: 'POST',
        //             headers: {
        //                 // 'Accept': 'application/json',
        //                 'Content-Type': 'application/json'
        //             },
        //             body: JSON.stringify({ 'question': 'which technology are utilized in smart vehical system?' }),
    
        //             //mode: 'no-cors' // Use 'cors' mode instead of 'no-cors'
    
        //         });
    
    
    
        //         const answer = await response.json();
        //         console.log("Answer from backend is: ", answer);
        //         dispatch(handleQandA({ que: inputValue, ans: answer }))
    
    
    
        //     } 
        //     catch (error) {
    
        //         console.error("Error fetching answer:", error);
    
    
    
        //     }
        // }
        // temp();   
    }, []);
    // }, [result]);




    return (
        <main className="Chats-UI">

            {/* chat-component-left-section  */}
            {!isLeftSectionToggle &&
                <section className="chat-component-left-section">
                    <div className="left-section-title-container">
                        <p className="left-section-title">Industries</p>
                        <img className="left-section-toggle-button toggle-button" src="./toggle-button-left-arrow.svg" alt="left-section-toogle-button" onClick={handleLeftSectionToggleButton} />
                    </div>
                    <div className="industry-data-container">
                        {industryData.map((industry, index) => (
                            <div className="industry-data">
                                <div className='industry-title-container' key={index}>
                                    <img id="industry-icon" src={industry.icon} alt="page-icon" />
                                    <p className='industry-name'>{industry.name}</p>

                                    <img id="expand-button" className="clickable-icon" src={isExpanded[index] ? "./up-arrow-icon.svg" : "./down-arrow-icon.svg"}
                                        alt="expand-button"
                                        onClick={() => handleExpandButton(index)} />
                                </div>

                                {isExpanded[index] && (
                                    <div className="industry-nested-data-container">
                                        {industry.nestedData.length > 0 ?

                                            industry.nestedData.map((item, index) => (
                                                <div className="industry-nested-data">
                                                    <img src="./bullet-point.svg" alt="bullet-point" id="bullet-point" />
                                                    <p key={index} className="industry-nested-items">{item}</p>
                                                </div>
                                            ))

                                            :
                                            <p style={{ color: "#969696", marginLeft: "1rem" }}>No details</p>
                                        }
                                    </div>

                                )
                                }
                                <div className="horizontal-line"></div>
                            </div>
                        ))}
                    </div>
                </section>
            }

            {isLeftSectionToggle &&
                <section className="shrunked-chat-component-left-section">
                    <div className="shrunked-left-section-container">
                        <div>
                            <img className="toggle-button" src="./left-section-toggle-button.svg" alt="left-section-toggle-button" onClick={handleLeftSectionToggleButton} />
                            <div className="shrunked-horizontal-line"></div>
                        </div>
                        {
                            industryData.map((industry, index) => (
                                <div className="industry-icon-container" key={index}>
                                    <img src={industry.icon} alt="industry-icons" />
                                    <div className="shrunked-horizontal-line"></div>
                                </div>
                            )
                            )
                        }
                    </div>
                </section>
            }

            {/* chat-component-main-section */}
            <section className={`chat-component-main-section ${isChatHistoryToggle ? 'shrink-right-section' : ''} 
            ${isLeftSectionToggle ? 'shrink-left-section' : ''}
            ${isChatHistoryToggle && isLeftSectionToggle ? 'expanded-main-section' : ''}`}
            >

                <div className="chat-component-main-container">

                    {/* search-box */}
                    <div className="search-box-container">
                        <div className="search-box">
                            <img className="search-icon" src="./search.svg" alt="search-icon"></img>
                            <input type="text" className="input-box" placeholder="Search"
                                value={inputValue}
                                onChange={handleInputChange}
                                onKeyDown={(e) => handleEnterPressed(e)}

                            />
                            <img id="send-button" className="clickable-icon" src="./send-button.svg" alt="send-button" onClick={handleSendQueryButton} />
                            <p className="vertical-line"></p>
                            <label htmlFor="uploadFileInput">
                                <img
                                    id="uploadFileButton"
                                    className="clickable-icon"
                                    src="./upload-file-button.svg"
                                    alt="upload-file-button"
                                />
                            </label>
                            <input
                                type="file"
                                id="uploadFileInput"
                                accept=".doc, .docx, .txt"
                                style={{ display: 'none' }}
                                onChange={handleFileUpload}
                            />
                        </div>

                        <div className="shrunked-right-section-button">
                            <img className="shrunked-new-chat-button" src="./plus-icon.svg" alt="new-chat-button" onClick={handleNewChatButton} />
                            <div className='vertical-line'></div>
                            <img className="toggle-button toggle-chat-history-button" src="./toggle-button-right-arrow.svg" alt="toggle-right-section-button" onClick={handleToggleChatHistoryButton} />
                        </div>

                    </div>


                    <div className="chats-conversation-container">
                        <div >

                            {/* default messages */}
                            {isDefaultMessages.map((message, index) => {
                                return (
                                    <div className="chats-conversation" key={index}>
                                        <div className="user">
                                            <img src="./profile-icon.svg" alt="profile" className="user-icon" />
                                            <p className="question">{message.ques}</p>
                                            <img className="clickable-icon" src="./copy-button.svg" alt="copy-button" onClick={() => handleCopy(message.ques)} />
                                        </div>
                                        <div className="bot">
                                            <img src="./brand-icon.svg" alt="bot-icon" />
                                            <p className="answer">{message.ans.response?.output_text}
                                            </p>
                                            <img className="clickable-icon" src="./copy-button.svg" alt="copy-button" onClick={() => handleCopy(message.ans)} />

                                        </div>
                                        <div className="share-download-button-container">
                                            <img src="./share-button.svg" alt="share-button" className="clickable-icon" />
                                            <img className="clickable-icon download-button" src="./download-button.svg" alt="download-button" onClick={() => handleDownload(message.text, defaultReply)} />
                                        </div>
                                    </div>
                                )
                            })}


                            {/* dynamic data */}
                            {queandans.map((message, index) => (
                                <div className="chats-conversation">
                                    <div className="user" key={index}>
                                        <img src="./profile-icon.svg" alt="profile" className="user-icon" />
                                        <p className="query">{message?.que}</p>
                                        <img className="clickable-icon" src="./copy-button.svg" alt="copy-button" onClick={() => handleCopy(message.text)} />
                                    </div>

                                    <div className="bot">
                                        <img src="./brand-icon.svg" alt="bot-icon" />
                                        {/* <p className="answer"> {defaultMessages.find(item => item.ques === message.text) ? defaultMessages.find(item => item.ques === message.text).ans : defaultReply}
                                        </p> */}

                                        <p>{message?.ans.answer}</p>

                                        <img className="clickable-icon" src="./copy-button.svg" alt="copy-button" onClick={() => handleCopy(answer)} />
                                    </div >

                                    <div className="share-download-button-container">
                                        <img src="./share-button.svg" alt="share-button" className="clickable-icon" />
                                        <img className="clickable-icon download-button" src="./download-button.svg" alt="download-button" onClick={() => handleDownload(message.text, defaultReply)} />
                                    </div>

                                </div>
                            ))}
                            {/* {userQuery.map((message, index) => (
                                <div className="chats-conversation">
                                    <div className="user" key={index}>
                                        <img src="./profile-icon.svg" alt="profile" className="user-icon" />
                                        <p className="question">{message.text}</p>
                                        <img className="clickable-icon" src="./copy-button.svg" alt="copy-button" onClick={() => handleCopy(message.text)} />
                                    </div>

                                    <div className="bot">
                                        <img src="./brand-icon.svg" alt="bot-icon" />

                                        <p>{answer}</p>

                                        <img className="clickable-icon" src="./copy-button.svg" alt="copy-button" onClick={() => handleCopy(answer)} />
                                    </div >

                                    <div className="share-download-button-container">
                                        <img src="./share-button.svg" alt="share-button" className="clickable-icon" />
                                        <img className="clickable-icon download-button" src="./download-button.svg" alt="download-button" onClick={() => handleDownload(message.text, defaultReply)} />
                                    </div>

                                </div>
                            ))} */}
                        </div>
                    </div>
                </div>
            </section>


            {/* chat-component right section */}

            <section className={`chat-component-right-section ${isChatHistoryToggle ? 'shrink-right-section' : ''}`}>
                <div className="chat-history-top">
                    <div className="clickable-icon" id="new-chat-button" onClick={handleNewChatButton}>
                        <img src="./plus-icon.svg" alt="new-chat-icon" className="new-chat-icon" />
                        <p className="new-chat-text"> New Chat</p>
                    </div>
                    <p className="vertical-line history-vertical-line"> </p>
                    <img id="toggle-chat-history-button" className="toggle-button" src='./toggle-button-right-arrow.svg' alt="toggle-button" onClick={handleToggleChatHistoryButton} />
                </div>


                {/* chat-history-section  */}
                <div className="chat-history-data-section-container">
                    {Object.keys(updatedChatHistory).map((date) => (
                        <div className="chat-history-data-section" key={date}>
                            {updatedChatHistory[date].length > 0 && <p className="date">{date}</p>}

                            {updatedChatHistory[date].map((topic, index) => (

                                <div className="history-container" key={index}>
                                    {editingIndices[date] === index ? (
                                        <div className="edit-section">
                                            <input className="editable-text"
                                                type="text"
                                                value={topic}
                                                onChange={(e) => {
                                                    const updatedHistory = { ...updatedChatHistory };
                                                    updatedHistory[date][index] = e.target.value;
                                                    setUpdatedChatHistory(updatedHistory);
                                                }}
                                            />
                                            <button className="save-button"
                                                onClick={() => {
                                                    setEditingIndices((prevEditingIndices) => ({
                                                        ...prevEditingIndices,
                                                        [date]: null,
                                                    }));
                                                }}
                                            >
                                                <img src="./save-button.svg" alt="save-button"></img>
                                            </button>
                                        </div>
                                    ) : (
                                        <>
                                            <img
                                                id="chat-history-icon"
                                                src="./clock-icon.svg"
                                                alt="chat-history-icon"
                                            />
                                            <p className="history">{topic}</p>
                                            <img
                                                className="clickable-icon edit-button"
                                                src="./edit-button.svg"
                                                alt="edit-button"
                                                onClick={() => handleEdit(date, index)}
                                            />
                                            <img
                                                className="clickable-icon delete-button"
                                                src="./delete-button.svg"
                                                alt="delete-button"
                                                onClick={() => handleDelete(date, index)}
                                            />
                                        </>
                                    )}
                                </div>

                            ))}

                        </div>
                    ))}
                </div>
            </section>

        </main >
    )
}

export default Chat;