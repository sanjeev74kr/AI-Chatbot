const chatHistory = {
     Today: ["Smart-tracking and its fundamentals","Smart-tracking and its details of inner function"],
    Yesterday:["Quantum-computing and its functionality","Smart computer vs dumb computer"],
    "Previous Week":["Quantum-computing and its functionality","Smart computer vs dumb computer","Smart-tracking and its fundamentals","Smart-tracking and its details of inner function","Smart-tracking and its fundamentals"]
};

export default chatHistory;