const industryData = [
  {
    icon: "./education-icon.svg",
    name: "Education",
    nestedData: ["Embracing Intranet", "Religious Learning"],
  },
  {
    icon: "./hitech-icon.svg",
    name: "Hi-Tech",
    nestedData: [],
  },
  {
    icon: "./power&utility-icon.svg",
    name: "Power & Utility",
    nestedData:["Power resources", "Project details"],
  },
  {
    icon: "./realstate-icon.svg",
    name: "Real-state",
    nestedData: [],
  },
  {
    icon: "./retail&fmcg-icon.svg",
    name: "Retail/FMCG",
    nestedData: [],
      },
  {   
    icon: "./transportation-icon.svg",
    name: "Transportation",
    nestedData: [],
  }
]

export default industryData;