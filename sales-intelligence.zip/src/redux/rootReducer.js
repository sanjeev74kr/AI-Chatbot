import { combineReducers } from "redux";
import { botReply } from "./queryReducer";

export default combineReducers({botReply});